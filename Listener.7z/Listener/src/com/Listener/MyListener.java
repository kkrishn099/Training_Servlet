package com.Listener;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class MyListener implements HttpSessionListener {

	static int total,current=0;
	ServletContext ctx = null;

	@Override
	public void sessionCreated(HttpSessionEvent se) {
		
		total++;
		current++;
		ctx = se.getSession().getServletContext();
		
		ctx.setAttribute("totalUsers",total );
		ctx.setAttribute("currentUsers", current);
		
		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		current--;
		ctx.setAttribute("currentUsers", current);
		
	}

}
