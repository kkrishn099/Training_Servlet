package com.Listener;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class MyServlet extends HttpServlet {
       @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
    	   
    	   resp.setContentType("text/html");
    	    PrintWriter out = resp.getWriter();
    	    String name = req.getParameter("userName");
    	       
    	    out.print("Welcome "+name);
    	    
    	    
    	    HttpSession sess =req.getSession();
    	        sess.setAttribute("userName", name);
    	        
    	        ServletContext ctx = getServletContext();
    	           int t =(Integer)ctx.getAttribute("totalUsers");
    	           int c =(Integer)ctx.getAttribute("currentUsers");
                   out.print("<br>TotalUsers ="+t);
                   out.print("<br>currentUsers ="+t);
                   out.print("<br><a href='logout'>Logout</a>");
                   out.close();
    }
}
